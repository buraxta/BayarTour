function createHeader() {
    var header = document.createElement('header');

    // First div
    var div1 = document.createElement('div');
    var logoLink = document.createElement('a');
    logoLink.href = 'main.html';
    var logoImg = document.createElement('img');
    logoImg.className = 'logo';
    logoImg.src = '../images/hermes_tour_logo.png';
    logoImg.alt = 'Hermes Tour';
    logoImg.title = 'Hermes Tour';
    logoLink.appendChild(logoImg);
    div1.appendChild(logoLink);

    // Second div
    var div2 = document.createElement('div');
    var ul1 = document.createElement('ul');
    var menuItems1 = ['Tours', 'Early Reservation', 'Campaigns', 'Contact', 'About Us'];
    menuItems1.forEach(function (itemText) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.href = itemText.toLowerCase() + '.html'; // Create link according to page name
        a.textContent = itemText;
        li.appendChild(a);
        ul1.appendChild(li);
    });
    div2.appendChild(ul1);

    // Third div
    var div3 = document.createElement('div');
    var ul2 = document.createElement('ul');
    var menuItems2 = ['Sign up', 'Login'];
    menuItems2.forEach(function (itemText) {
        var li = document.createElement('li');
        var a = document.createElement('a');
        a.href = 'login.html';
        a.textContent = itemText;
        li.appendChild(a);
        ul2.appendChild(li);
    });
    div3.appendChild(ul2);

    // add header the children
    header.appendChild(div1);
    header.appendChild(div2);
    header.appendChild(div3);

    // Add header to the page
    document.body.insertBefore(header, document.body.firstChild);
}

/*
<header>
                <div>
                    <a href="main.html">
                        <img class="logo" src="../images/hermes_tour_logo.png" alt="Hermes Tour" title="Hermes Tour">
                    </a>
                </div>

                <div>
                    <ul>
                        <li><a href="tours.html">Tours</a></li>
                        <li><a href="#news">Early Reservation</a></li>
                        <li><a href="campaigns.html">Campaigns</a></li>
                        <li><a href="contact.html">Contact</a></li>
                        <li><a href="aboutus.html">About Us</a></li>
                    </ul>
                </div>

                <div>
                    <ul>
                        <li><a href="login.html">Sign up</a></li>
                        <li><a href="login.html">Login</a></li>
                    </ul>
                </div>
        </header>
*/

function tomorrowDate() {
    // Today date
    var today = new Date();
                
    // Tomorrow date
    var tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);

    // create string form YYYY-MM-DD 
    var tomorrowString = tomorrow.toISOString().split('T')[0];

    // Find the element from its id and align the value
    document.getElementById('date').value = tomorrowString;
}